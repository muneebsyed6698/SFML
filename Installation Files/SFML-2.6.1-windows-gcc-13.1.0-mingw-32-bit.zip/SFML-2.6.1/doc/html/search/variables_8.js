var searchData=
[
  ['joystickbutton_0',['joystickButton',['../classsf_1_1Event.html#a42aad27a054c1c05bd5c3d020e1db174',1,'sf::Event']]],
  ['joystickconnect_1',['joystickConnect',['../classsf_1_1Event.html#aa354335c9ad73362442bc54ffe81118f',1,'sf::Event']]],
  ['joystickid_2',['joystickId',['../structsf_1_1Event_1_1JoystickConnectEvent.html#a08e58e8559d3e4fe4654855fec79194b',1,'sf::Event::JoystickConnectEvent::joystickId'],['../structsf_1_1Event_1_1JoystickMoveEvent.html#a7bf2b2f2941a21ed26a67c95f5e4232f',1,'sf::Event::JoystickMoveEvent::joystickId'],['../structsf_1_1Event_1_1JoystickButtonEvent.html#a2f80ecdb964a5ae0fc30726a404c41ec',1,'sf::Event::JoystickButtonEvent::joystickId']]],
  ['joystickmove_3',['joystickMove',['../classsf_1_1Event.html#ac479e8351cc2024d5c1094dc33970f7f',1,'sf::Event']]]
];
