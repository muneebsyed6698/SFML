var searchData=
[
  ['fileinputstream_0',['FileInputStream',['../classsf_1_1FileInputStream.html#a9a321e273f41ff7f187899061fcae9be',1,'sf::FileInputStream']]],
  ['find_1',['find',['../classsf_1_1String.html#aa189ec8656854106ab8d2e935fd9cbcc',1,'sf::String']]],
  ['findcharacterpos_2',['findCharacterPos',['../classsf_1_1Text.html#a2e252d8dcae3eb61c6c962c0bc674b12',1,'sf::Text']]],
  ['fliphorizontally_3',['flipHorizontally',['../classsf_1_1Image.html#a57168e7bc29190e08bbd6c9c19f4bb2c',1,'sf::Image']]],
  ['flipvertically_4',['flipVertically',['../classsf_1_1Image.html#a78a702a7e49d1de2dec9894da99d279c',1,'sf::Image']]],
  ['font_5',['Font',['../classsf_1_1Font.html#a506404655b8869ed60d1e7709812f583',1,'sf::Font::Font()'],['../classsf_1_1Font.html#a72d7322b355ee2f1be4500f530e98081',1,'sf::Font::Font(const Font &amp;copy)']]],
  ['fromansi_6',['fromAnsi',['../classsf_1_1Utf_3_0132_01_4.html#a384a4169287af15876783ad477cac4e3',1,'sf::Utf&lt; 32 &gt;::fromAnsi()'],['../classsf_1_1Utf_3_0116_01_4.html#a8a595dc1ea57ecf7aad944964913f0ff',1,'sf::Utf&lt; 16 &gt;::fromAnsi()'],['../classsf_1_1Utf_3_018_01_4.html#a1b62ba85ad3c8ce68746e16192b3eef0',1,'sf::Utf&lt; 8 &gt;::fromAnsi(In begin, In end, Out output, const std::locale &amp;locale=std::locale())']]],
  ['fromlatin1_7',['fromLatin1',['../classsf_1_1Utf_3_018_01_4.html#a85dd3643b7109a1a2f802747e55e28e8',1,'sf::Utf&lt; 8 &gt;::fromLatin1()'],['../classsf_1_1Utf_3_0116_01_4.html#a52293df75893733fe6cf84b8a017cbf7',1,'sf::Utf&lt; 16 &gt;::fromLatin1()'],['../classsf_1_1Utf_3_0132_01_4.html#a05741b76b5a26267a72735e40ca61c55',1,'sf::Utf&lt; 32 &gt;::fromLatin1()']]],
  ['fromutf16_8',['fromUtf16',['../classsf_1_1String.html#a81f70eecad0000a4f2e4d66f97b80300',1,'sf::String']]],
  ['fromutf32_9',['fromUtf32',['../classsf_1_1String.html#ab023a4900dce37ee71ab9e29b30a23cb',1,'sf::String']]],
  ['fromutf8_10',['fromUtf8',['../classsf_1_1String.html#aa7beb7ae5b26e63dcbbfa390e27a9e4b',1,'sf::String']]],
  ['fromwide_11',['fromWide',['../classsf_1_1Utf_3_018_01_4.html#aa99e636a7addc157b425dfc11b008f42',1,'sf::Utf&lt; 8 &gt;::fromWide()'],['../classsf_1_1Utf_3_0116_01_4.html#a263423929b6f8e4d3ad09b45ac5cb0a1',1,'sf::Utf&lt; 16 &gt;::fromWide()'],['../classsf_1_1Utf_3_0132_01_4.html#abdf0d41e0c8814a68326688e3b8d187f',1,'sf::Utf&lt; 32 &gt;::fromWide()']]]
];
