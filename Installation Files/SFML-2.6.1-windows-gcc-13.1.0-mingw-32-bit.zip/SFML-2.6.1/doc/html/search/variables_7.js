var searchData=
[
  ['identity_0',['Identity',['../classsf_1_1Transform.html#aa4eb1eecbcb9979d76e2543b337fdb13',1,'sf::Transform']]],
  ['invalidpos_1',['InvalidPos',['../classsf_1_1String.html#abaadecaf12a6b41c54d725c75fd28527',1,'sf::String']]]
];
